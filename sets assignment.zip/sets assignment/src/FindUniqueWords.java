import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;

public class FindUniqueWords {
    public static void main(String[] args) throws Exception {
        Path path = Paths.get(System.getProperty("user.dir")).resolve("illiad.txt");

        BufferedReader reader = new BufferedReader(new FileReader(path.toFile()));

        Set<String> wordsInText = new HashSet<>();

        String line = reader.readLine();

        while(line != null) {
//            System.out.println(line);
            if (!line.trim().equals("")) {
                String[] words = line.split(" ");

                for (String word : words) {
                    String w = word.toLowerCase()
                            .replace(",", "")
                            .replace("." , "")
                            .replace(":", "")
                            .replace(";", "")
                            .replace("/", "")
                            .replace("!", "")
                            .replace("?", "")
                            .replace("\"", "")
                            .replace("\'", "");
                    wordsInText.add(w);
                }

            }
            line = reader.readLine();
        }

//        System.out.println(wordsInText);
        System.out.println("There are " + wordsInText.size() + " unique words in the text");

    }
}
