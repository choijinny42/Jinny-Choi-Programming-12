package com.jinnychoi.module1_4;

public interface Rotate {
    void rotate90();
    void rotate180();
    void rotate(double degree);
}
