package com.jinnychoi.module1_4;

public enum Colour {
    RED, GREEN, BLUE, NONE;
}
