package com.jinnychoi.module1_3;

public interface Rotate {
    void rotate90();
    void rotate180();
    void rotate(double degree);
}
